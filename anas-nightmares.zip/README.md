# Anas-Nightmares

Bem-vindo ao **Anas-Nightmares**: um site sombrio e estilizado que mergulha o visitante em uma experiência visual e textual de um pesadelo interativo.

## Acessibilidade
- Modo de **Alto Contraste** (`Ctrl + A`)
- Fonte **Ampliada** (`Ctrl + F`)

## Imagens
O site utiliza imagens macabras para ambientar a experiência de leitura. Veja abaixo uma prévia:

### O Início do Pesadelo
![Pesadelo](imagens/pesadelo1.jpg)

### O Despertar do Monstro
![Monstro](imagens/monstro.jpg)

## Publicação

Este projeto está publicado no GitHub Pages e pode ser acessado em:

**https://SeuUsuario.github.io/anas-nightmares/**

## Licença
© 2025 Anas-Nightmares. Todos os direitos reservados.
